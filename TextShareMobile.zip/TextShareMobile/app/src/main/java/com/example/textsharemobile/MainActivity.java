package com.example.textsharemobile;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {

    // declaring required variables
    private Socket client;
    private PrintWriter printwriter;
    private BufferedReader bufferedReader;
    private EditText portField, ipField, messageField, Lang;
    private TextView responseField;
    private Button sendButton;
    private String message, ip;
    private CheckBox Translate;
    private int port;

    // handler to update UI from background thread
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // reference to UI elements
        messageField = findViewById(R.id.edit_text);
        ipField = findViewById(R.id.edit_ip);
        portField = findViewById(R.id.edit_port);
        //responseField = findViewById(R.id.text_view);
        sendButton = findViewById(R.id.send_button);
        Translate = findViewById(R.id.Translate);
        Lang = findViewById(R.id.language);
        message = "TextRequest:";

        // Button press event listener
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // get input values from UI elements
                if (Translate.isChecked()){
                    message += "tr:" + Lang.getText().toString();
                }

                ip = "192.168.1.147";
                port = 4444;

                // start the Thread to connect to server
                new Thread(new ClientThread(message, ip, port)).start();
                message = "TextRequest:";
            }
        });

    }

    public void Chek(View v)
    {

    }

    // the ClientThread class performs
    // the networking operations
    class ClientThread implements Runnable {
        private final String message;
        private final String ip;
        private final int port;

        ClientThread(String message, String ip, int port) {
            this.message = message;
            this.ip = ip;
            this.port = port;
        }
        @Override
        public void run() {
            try {
                // Creates a stream socket and connects it to the specified port number on the named host.
                client = new Socket(ip, port); // connect to server
                printwriter = new PrintWriter(client.getOutputStream(),true);
                printwriter.write(message); // write the message to output stream
                printwriter.flush();

                // read response from server
                bufferedReader = new BufferedReader(new InputStreamReader(client.getInputStream()));
                final String response = bufferedReader.readLine();


                // close connections
                //printwriter.close();
                //bufferedReader.close();
                //client.close();

                // update UI with response from server
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        messageField.setText(response);
                    }
                });

            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }
}
